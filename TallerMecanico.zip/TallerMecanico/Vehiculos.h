#ifndef VEHICULOS_H_INCLUDED
#define VEHICULOS_H_INCLUDED

class clsVehiculo {

 char _numPatente[8];
 char _descripcionFalla [100];
 char _marca [20];
 Fecha ingreso;

 char _tipoVehiculo ;

};

#endif // VEHICULOS_H_INCLUDED
