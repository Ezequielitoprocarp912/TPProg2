#include <iostream>

class clsFecha
{
private:
    int _dia;
    int _mes;
    int _anio;
    bool validarFecha();
    bool esBisiesto(int);
public:
    int getDia();
    int getMes();
    int getAnio();
    void setDia(int);
    void setMes(int);
    void setAnio(int);
    clsFecha();
    clsFecha(int, int, int);
    std::string toString();


bool operator == (clsFecha);
};


