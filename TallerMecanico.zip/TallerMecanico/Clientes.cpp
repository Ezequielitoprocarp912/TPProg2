#include <iostream>
#include <string>
#include <cstring>
#include "Clientes.h"


///CONSTRUCTORES
clsCliente::clsCliente() /// CONSTRUCTOR DEFAULT
{
    strcpy(_cuit, "SIN CUIT");
    strcpy(_nombre, "SIN NOMBRE");
    strcpy(_apellido, "SIN APELLIDO");
    strcpy(_mail, "SIN MAIL");
    strcpy(_direccion, "SIN DIRECCION");
    _tipoCliente=0; /// 0 default - 1 particular - 2 empresa
}

///CONSTRUCTOR CON PARAMETROS
clsCliente::clsCliente(std::string cuit, std::string nombre, std::string apellido, std::string mail, std::string direccion, int tipoCliente = 0)
{
    strcpy(_cuit, "SIN CUIT");
    strcpy(_nombre, "SIN NOMBRE");
    strcpy(_apellido, "SIN APELLIDO");
    strcpy(_mail, "SIN MAIL");
    strcpy(_direccion, "SIN DIRECCION");
    _tipoCliente=0; /// 0 default - 1 particular - 2 empresa

}

///SETTERS
void clsCliente::setCuit (std::string cuit)
{
    strcpy(_cuit, cuit.c_str());
}
void clsCliente::setNombre (std::string nombre)
{
    strcpy(_nombre, nombre.c_str());
}
void clsCliente::setApellido (std::string apellido)
{
    strcpy(_apellido, apellido.c_str());
}
void clsCliente::setMail (std::string mail)
{
    strcpy(_mail, mail.c_str());
}
void clsCliente::setDireccion (std::string direccion)
{
    strcpy(_direccion, direccion.c_str());
}
void clsCliente::setTipoCliente (int tipoCliente)
{
    _tipoCliente=tipoCliente;
}


///GETTERS
std::string clsCliente::getCuit()
{
    return _cuit;
}
std::string clsCliente::getNombre()
{
    return _nombre;
}
std::string clsCliente::getApellido()
{
    return _apellido;
}
std::string clsCliente::getMail()
{
    return _mail;
}
std::string clsCliente::getDireccion()
{
    return _direccion;
}
int clsCliente::getTipoCliente()
{
    return _tipoCliente;
}

