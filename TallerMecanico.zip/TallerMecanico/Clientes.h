#ifndef CLIENTES_H_INCLUDED
#define CLIENTES_H_INCLUDED

class clsCliente
{

///ATRIBUTOS
private:
    char _cuit[12];
    char _nombre[20];
    char _apellido[20];
    char _numTelefono[20];
    char _mail[50];
    char _direccion [50];
    int _tipoCliente; /// 1 particular - 2 empresa


public:
///CONSTRUCTORES
    clsCliente(); /// Constructor DEFAULT
    clsCliente(std::string cuit, std::string nombre, std::string apellido, std::string mail, std::string direccion, int tipoCliente);


///SETTERS
    void setCuit (std::string cuit);
    void setNombre (std::string nombre);
    void setApellido (std::string apellido);
    void setMail (std::string mail);
    void setDireccion (std::string direccion);
    void setTipoCliente (int tipoCliente);


///GETTERS
    std::string getCuit();
    std::string getNombre();
    std::string getApellido();
    std::string getMail();
    std::string getDireccion();
    int getTipoCliente();

};



#endif // CLIENTES_H_INCLUDED
